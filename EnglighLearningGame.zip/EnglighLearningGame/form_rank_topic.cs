﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_rank_topic : Form
    {
        public form_rank_topic()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
             this.Close();
           
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_furnitures_Click(object sender, EventArgs e)
        {
            form_rank form_Rank = new form_rank();
            form_Rank.topic = 2;
            form_Rank.ShowDialog();
        }

        private void ptb_animals_Click(object sender, EventArgs e)
        {
            form_rank form_Rank = new form_rank();
            form_Rank.topic = 0;
            form_Rank.ShowDialog();
        }

        private void ptb_fruits_Click(object sender, EventArgs e)
        {
            form_rank form_Rank = new form_rank();
            form_Rank.topic = 1;
            form_Rank.ShowDialog();
        }

        private void ptb_vehicles_Click(object sender, EventArgs e)
        {
            form_rank form_Rank = new form_rank();
            form_Rank.topic = 3;
            form_Rank.ShowDialog();
        }
    }
}
