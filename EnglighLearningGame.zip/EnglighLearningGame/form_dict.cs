﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_dict : Form
    {
        public form_dict()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ptb_furnitures_Click(object sender, EventArgs e)
        {
            this.Hide();
            form_dict_furnitures form_Dict_Furnitures = new form_dict_furnitures();
            form_Dict_Furnitures.ShowDialog();
           
        }

        private void ptb_animals_Click(object sender, EventArgs e)
        {
            this.Hide();
            form_dict_animals form_Dict_Animals = new form_dict_animals();
            form_Dict_Animals.ShowDialog();
        }

        private void ptb_fruits_Click(object sender, EventArgs e)
        {
            this.Hide();
            form_dict_fruits form_Dict_Fruits = new form_dict_fruits();
            form_Dict_Fruits.ShowDialog();
        }

        private void ptb_vehicles_Click(object sender, EventArgs e)
        {
            this.Hide();
            form_dict_vehicles form_Dict_Vehicles = new form_dict_vehicles();
            form_Dict_Vehicles.ShowDialog();
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.SoundLocation = @".\music.wav";
            sp.PlayLooping();
            ptb_playms.Visible = false;
            ptb_mute.Visible = true;
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.SoundLocation = @".\music.wav";
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }
    }
}
