﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_topic : Form
    {
        public form_topic()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
             this.Close();
            form_welcome form_Welcome = new form_welcome();
            form_Welcome.Show();
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ptb_furnitures_Click(object sender, EventArgs e)
        {
            this.Hide();
           form_game_furnitures form_Game_Furnitures = new form_game_furnitures();
            form_Game_Furnitures.ShowDialog();
           
        }

        private void ptb_animals_Click(object sender, EventArgs e)
        {
            this.Hide();
            form_game_animals f = new form_game_animals();
            f.ShowDialog();
          
        }

        private void ptb_fruits_Click(object sender, EventArgs e)
        {
            this.Hide();
            form_game_fruits form_Game_Fruits = new form_game_fruits();
            form_Game_Fruits.ShowDialog();
           
        }

        private void ptb_vehicles_Click(object sender, EventArgs e)
        {
            this.Hide();
            form_game_vehicles form_Game_Vehicles = new form_game_vehicles();
            form_Game_Vehicles.ShowDialog();    
          
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }
    }
}
