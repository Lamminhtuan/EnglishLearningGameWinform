﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace TH01
{
    public partial class form_rank : Form
    {
        public int topic { get; set; }
        public form_rank()
        {
            InitializeComponent();
        }

       
        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
          
        }

        private void form_rank_Load(object sender, EventArgs e)
        {
            if (topic == 0)
            {
            
                lb_animals.Visible = true;
                if (Rank_animals.dt.Rows.Count == 0)
                {
                    ptb_gold.Visible = false;
                    ptb_bronze.Visible = false;
                    ptb_silver.Visible = false;
                    lb_norow.Visible = true;
                    lb_gold_name.Visible = false;
                    lb_gold_score.Visible = false;
                    lb_gold_time.Visible = false;
                    lb_gold_total.Visible = false;
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_animals.dt.Rows.Count == 1)
                {
                    lb_norow.Visible = false;
                    ptb_bronze.Visible = false;
                    ptb_silver.Visible = false;
                    lb_gold_name.Text = Rank_animals.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_animals.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_animals.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_animals.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_animals.dt.Rows.Count == 2)
                {
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = false;
                    lb_gold_name.Text = Rank_animals.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_animals.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_animals.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_animals.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_animals.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_animals.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_animals.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_animals.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else
                {
                    Rank_animals.dt.DefaultView.Sort = "Score DESC, Total ASC";
                    Rank_animals.dt = Rank_animals.dt.DefaultView.ToTable();
               
                    lb_gold_name.Text = Rank_animals.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_animals.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_animals.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_animals.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_animals.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_animals.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_animals.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_animals.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Text = Rank_animals.dt.Rows[2]["Name"].ToString();
                    lb_bronze_score.Text = Rank_animals.dt.Rows[2]["Score"].ToString();
                    lb_bronze_time.Text = Rank_animals.dt.Rows[2]["Time"].ToString();
                    lb_bronze_total.Text = Rank_animals.dt.Rows[2]["Total"].ToString();
                }
            }
            else if (topic == 1)
            {
                lb_fruits.Visible = true;
                if (Rank_fruits.dt.Rows.Count == 0)
                {
                    ptb_gold.Visible = false;
                    ptb_bronze.Visible = false;
                    ptb_silver.Visible = false;
                    lb_norow.Visible = true;
                    lb_gold_name.Visible = false;
                    lb_gold_score.Visible = false;
                    lb_gold_time.Visible = false;
                    lb_gold_total.Visible = false;
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_fruits.dt.Rows.Count == 1)
                {
                    ptb_bronze.Visible = false;
                    ptb_silver.Visible = false;
                    lb_norow.Visible = false;
                    lb_gold_name.Text = Rank_fruits.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_fruits.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_fruits.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_fruits.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_fruits.dt.Rows.Count == 2)
                {
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = false;
                    lb_gold_name.Text = Rank_fruits.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_fruits.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_fruits.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_fruits.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_fruits.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_fruits.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_fruits.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_fruits.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else
                {
                    Rank_fruits.dt.DefaultView.Sort = "Score DESC, Total ASC";
                    Rank_fruits.dt = Rank_fruits.dt.DefaultView.ToTable();
                 
                    lb_gold_name.Text = Rank_fruits.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_fruits.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_fruits.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_fruits.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_fruits.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_fruits.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_fruits.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_fruits.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Text = Rank_fruits.dt.Rows[2]["Name"].ToString();
                    lb_bronze_score.Text = Rank_fruits.dt.Rows[2]["Score"].ToString();
                    lb_bronze_time.Text = Rank_fruits.dt.Rows[2]["Time"].ToString();
                    lb_bronze_total.Text = Rank_fruits.dt.Rows[2]["Total"].ToString();
                }
            }
            else if (topic == 2)
            {
                lb_furnitures.Visible = true;
                if (Rank_furnitures.dt.Rows.Count == 0)
                {
                    ptb_gold.Visible = false;
                    ptb_silver.Visible = false;
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = true;
                    lb_gold_name.Visible = false;
                    lb_gold_score.Visible = false;
                    lb_gold_time.Visible = false;
                    lb_gold_total.Visible = false;
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_furnitures.dt.Rows.Count == 1)
                {
                    ptb_silver.Visible = false;
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = false;
                    lb_gold_name.Text = Rank_furnitures.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_furnitures.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_furnitures.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_furnitures.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_furnitures.dt.Rows.Count == 2)
                {
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = false;
                    lb_gold_name.Text = Rank_furnitures.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_furnitures.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_furnitures.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_furnitures.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_furnitures.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_furnitures.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_furnitures.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_furnitures.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else
                {
                    Rank_furnitures.dt.DefaultView.Sort = "Score DESC, Total ASC";
                    Rank_furnitures.dt = Rank_furnitures.dt.DefaultView.ToTable();
                
                    lb_gold_name.Text = Rank_furnitures.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_furnitures.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_furnitures.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_furnitures.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_furnitures.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_furnitures.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_furnitures.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_furnitures.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Text = Rank_furnitures.dt.Rows[2]["Name"].ToString();
                    lb_bronze_score.Text = Rank_furnitures.dt.Rows[2]["Score"].ToString();
                    lb_bronze_time.Text = Rank_furnitures.dt.Rows[2]["Time"].ToString();
                    lb_bronze_total.Text = Rank_furnitures.dt.Rows[2]["Total"].ToString();
                }
            }
            else
            {
                lb_vehicles.Visible = true;
                if (Rank_vehicles.dt.Rows.Count == 0)
                {
                    ptb_gold.Visible = false;
                    ptb_silver.Visible = false;
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = true;
                    lb_gold_name.Visible = false;
                    lb_gold_score.Visible = false;
                    lb_gold_time.Visible = false;
                    lb_gold_total.Visible = false;
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_vehicles.dt.Rows.Count == 1)
                {
                    ptb_silver.Visible = false;
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = false;
                    lb_gold_name.Text = Rank_vehicles.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_vehicles.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_vehicles.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_vehicles.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Visible = false;
                    lb_silver_score.Visible = false;
                    lb_silver_time.Visible = false;
                    lb_silver_total.Visible = false;
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else if (Rank_vehicles.dt.Rows.Count == 2)
                {
                    ptb_bronze.Visible = false;
                    lb_norow.Visible = false;
                    lb_gold_name.Text = Rank_vehicles.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_vehicles.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_vehicles.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_vehicles.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_vehicles.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_vehicles.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_vehicles.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_vehicles.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Visible = false;
                    lb_bronze_score.Visible = false;
                    lb_bronze_time.Visible = false;
                    lb_bronze_total.Visible = false;
                }
                else
                {
                    Rank_vehicles.dt.DefaultView.Sort = "Score DESC, Total ASC";
                    Rank_vehicles.dt = Rank_vehicles.dt.DefaultView.ToTable();
                    lb_gold_name.Text = Rank_vehicles.dt.Rows[0]["Name"].ToString();
                    lb_gold_score.Text = Rank_vehicles.dt.Rows[0]["Score"].ToString();
                    lb_gold_time.Text = Rank_vehicles.dt.Rows[0]["Time"].ToString();
                    lb_gold_total.Text = Rank_vehicles.dt.Rows[0]["Total"].ToString();
                    lb_silver_name.Text = Rank_vehicles.dt.Rows[1]["Name"].ToString();
                    lb_silver_score.Text = Rank_vehicles.dt.Rows[1]["Score"].ToString();
                    lb_silver_time.Text = Rank_vehicles.dt.Rows[1]["Time"].ToString();
                    lb_silver_total.Text = Rank_vehicles.dt.Rows[1]["Total"].ToString();
                    lb_bronze_name.Text = Rank_vehicles.dt.Rows[2]["Name"].ToString();
                    lb_bronze_score.Text = Rank_vehicles.dt.Rows[2]["Score"].ToString();
                    lb_bronze_time.Text = Rank_vehicles.dt.Rows[2]["Time"].ToString();
                    lb_bronze_total.Text = Rank_vehicles.dt.Rows[2]["Total"].ToString();
                }
            }
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
