﻿namespace TH01
{
    partial class form_game_vehicles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_game_vehicles));
            this.ptb_close = new System.Windows.Forms.PictureBox();
            this.btn_back = new System.Windows.Forms.PictureBox();
            this.ptb_mute = new System.Windows.Forms.PictureBox();
            this.ptb_playms = new System.Windows.Forms.PictureBox();
            this.tb_word = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ptb_image = new System.Windows.Forms.PictureBox();
            this.ptb_true = new System.Windows.Forms.PictureBox();
            this.lb_score = new System.Windows.Forms.Label();
            this.ptb_false = new System.Windows.Forms.PictureBox();
            this.timer_game = new System.Windows.Forms.Timer(this.components);
            this.lb_timer = new System.Windows.Forms.Label();
            this.ptb_timesup = new System.Windows.Forms.PictureBox();
            this.lb_name = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_true)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_false)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_timesup)).BeginInit();
            this.SuspendLayout();
            // 
            // ptb_close
            // 
            this.ptb_close.BackColor = System.Drawing.Color.Transparent;
            this.ptb_close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_close.BackgroundImage")));
            this.ptb_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_close.Location = new System.Drawing.Point(894, 12);
            this.ptb_close.Name = "ptb_close";
            this.ptb_close.Size = new System.Drawing.Size(50, 50);
            this.ptb_close.TabIndex = 2;
            this.ptb_close.TabStop = false;
            this.ptb_close.Click += new System.EventHandler(this.ptb_close_Click);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.Transparent;
            this.btn_back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_back.BackgroundImage")));
            this.btn_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_back.Location = new System.Drawing.Point(12, 12);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(50, 50);
            this.btn_back.TabIndex = 3;
            this.btn_back.TabStop = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // ptb_mute
            // 
            this.ptb_mute.BackColor = System.Drawing.Color.Transparent;
            this.ptb_mute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_mute.BackgroundImage")));
            this.ptb_mute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_mute.Location = new System.Drawing.Point(894, 478);
            this.ptb_mute.Name = "ptb_mute";
            this.ptb_mute.Size = new System.Drawing.Size(50, 50);
            this.ptb_mute.TabIndex = 12;
            this.ptb_mute.TabStop = false;
            this.ptb_mute.Click += new System.EventHandler(this.ptb_mute_Click);
            // 
            // ptb_playms
            // 
            this.ptb_playms.BackColor = System.Drawing.Color.Transparent;
            this.ptb_playms.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_playms.BackgroundImage")));
            this.ptb_playms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_playms.Location = new System.Drawing.Point(894, 478);
            this.ptb_playms.Name = "ptb_playms";
            this.ptb_playms.Size = new System.Drawing.Size(50, 50);
            this.ptb_playms.TabIndex = 11;
            this.ptb_playms.TabStop = false;
            this.ptb_playms.Click += new System.EventHandler(this.ptb_playms_Click);
            // 
            // tb_word
            // 
            this.tb_word.BackColor = System.Drawing.Color.Gray;
            this.tb_word.Font = new System.Drawing.Font("UTM Centur", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tb_word.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tb_word.Location = new System.Drawing.Point(343, 434);
            this.tb_word.Name = "tb_word";
            this.tb_word.Size = new System.Drawing.Size(232, 42);
            this.tb_word.TabIndex = 13;
            this.tb_word.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb_word.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_word_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("UTM Amerika Sans", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(310, 23);
            this.label1.MaximumSize = new System.Drawing.Size(500, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 89);
            this.label1.TabIndex = 15;
            this.label1.Text = "VEHICLES";
            // 
            // ptb_image
            // 
            this.ptb_image.BackColor = System.Drawing.Color.Transparent;
            this.ptb_image.BackgroundImage = global::TH01.Properties.Resources.cat;
            this.ptb_image.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_image.ImageLocation = "";
            this.ptb_image.Location = new System.Drawing.Point(224, 105);
            this.ptb_image.Name = "ptb_image";
            this.ptb_image.Size = new System.Drawing.Size(488, 323);
            this.ptb_image.TabIndex = 16;
            this.ptb_image.TabStop = false;
            this.ptb_image.BackgroundImageChanged += new System.EventHandler(this.ptb_image_BackgroundImageChanged);
            this.ptb_image.Click += new System.EventHandler(this.ptb_image_Click);
            // 
            // ptb_true
            // 
            this.ptb_true.AccessibleDescription = "";
            this.ptb_true.BackColor = System.Drawing.Color.Transparent;
            this.ptb_true.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_true.BackgroundImage")));
            this.ptb_true.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_true.Location = new System.Drawing.Point(742, 49);
            this.ptb_true.Name = "ptb_true";
            this.ptb_true.Size = new System.Drawing.Size(125, 112);
            this.ptb_true.TabIndex = 17;
            this.ptb_true.TabStop = false;
            this.ptb_true.Visible = false;
            // 
            // lb_score
            // 
            this.lb_score.AutoSize = true;
            this.lb_score.BackColor = System.Drawing.Color.Transparent;
            this.lb_score.Font = new System.Drawing.Font("Courier New", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_score.ForeColor = System.Drawing.Color.PaleGreen;
            this.lb_score.Location = new System.Drawing.Point(98, 320);
            this.lb_score.Name = "lb_score";
            this.lb_score.Size = new System.Drawing.Size(51, 54);
            this.lb_score.TabIndex = 18;
            this.lb_score.Text = "0";
            // 
            // ptb_false
            // 
            this.ptb_false.AccessibleDescription = "";
            this.ptb_false.BackColor = System.Drawing.Color.Transparent;
            this.ptb_false.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_false.BackgroundImage")));
            this.ptb_false.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_false.Location = new System.Drawing.Point(742, 196);
            this.ptb_false.Name = "ptb_false";
            this.ptb_false.Size = new System.Drawing.Size(125, 112);
            this.ptb_false.TabIndex = 17;
            this.ptb_false.TabStop = false;
            this.ptb_false.Visible = false;
            // 
            // timer_game
            // 
            this.timer_game.Enabled = true;
            this.timer_game.Interval = 1000;
            this.timer_game.Tick += new System.EventHandler(this.timer_game_Tick);
            // 
            // lb_timer
            // 
            this.lb_timer.AutoSize = true;
            this.lb_timer.BackColor = System.Drawing.Color.Transparent;
            this.lb_timer.Font = new System.Drawing.Font("UTM Alberta Heavy", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_timer.ForeColor = System.Drawing.Color.IndianRed;
            this.lb_timer.Location = new System.Drawing.Point(89, 83);
            this.lb_timer.Name = "lb_timer";
            this.lb_timer.Size = new System.Drawing.Size(95, 106);
            this.lb_timer.TabIndex = 19;
            this.lb_timer.Text = "1";
            // 
            // ptb_timesup
            // 
            this.ptb_timesup.AccessibleDescription = "";
            this.ptb_timesup.BackColor = System.Drawing.Color.Transparent;
            this.ptb_timesup.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_timesup.BackgroundImage")));
            this.ptb_timesup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_timesup.Location = new System.Drawing.Point(742, 345);
            this.ptb_timesup.Name = "ptb_timesup";
            this.ptb_timesup.Size = new System.Drawing.Size(125, 112);
            this.ptb_timesup.TabIndex = 17;
            this.ptb_timesup.TabStop = false;
            this.ptb_timesup.Visible = false;
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_name.Font = new System.Drawing.Font("Courier New", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_name.ForeColor = System.Drawing.Color.ForestGreen;
            this.lb_name.Location = new System.Drawing.Point(59, 238);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(135, 54);
            this.lb_name.TabIndex = 18;
            this.lb_name.Text = "Tuấn";
            // 
            // form_game_vehicles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(956, 540);
            this.Controls.Add(this.lb_timer);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.lb_score);
            this.Controls.Add(this.ptb_timesup);
            this.Controls.Add(this.ptb_false);
            this.Controls.Add(this.ptb_true);
            this.Controls.Add(this.ptb_image);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_word);
            this.Controls.Add(this.ptb_mute);
            this.Controls.Add(this.ptb_playms);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.ptb_close);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form_game_vehicles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_game_vehicles";
            this.Load += new System.EventHandler(this.form_game_vehicles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_true)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_false)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_timesup)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox ptb_close;
        private PictureBox btn_back;
        private PictureBox ptb_mute;
        private PictureBox ptb_playms;
        private TextBox tb_word;
        private Label label1;
        private PictureBox ptb_image;
        private PictureBox ptb_true;
        private Label lb_score;
        private PictureBox ptb_false;
     
        private System.Windows.Forms.Timer timer_game;
        private Label lb_timer;
        private PictureBox ptb_timesup;
        private Label lb_name;
    }
}