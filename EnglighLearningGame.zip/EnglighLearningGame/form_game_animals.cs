﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Timers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TH01
{
    public partial class form_game_animals : Form
    {
        int second = 0;
        int score = 0;
        int count = 1;
        int idx;
        int totaltime = 0;
        string now;
        List<KeyValuePair<int, string>> dict = new List<KeyValuePair<int, string>>();
        List<Bitmap> picturelist = new List<Bitmap>();
        List<int> used = new List<int>();
        public form_game_animals()
        {
            InitializeComponent();
        }
        public void RandomChange(List<Bitmap> list)
        {
            int temp;
            Random random = new Random();
            do
            {
                temp = random.Next(0, list.Count);
            } while (used.Contains(temp));
            used.Add(temp);
            idx = temp;
            ptb_image.BackgroundImage = list[idx];
        }

        private void form_game_animals_Load(object sender, EventArgs e)
        {
            lb_name.Text = Global.Name;
            second = 7;
            timer_game.Start();


            lb_score.Text = score.ToString();
            dict.Add(new KeyValuePair<int, string>(0, "elephant"));
            dict.Add(new KeyValuePair<int, string>(1, "cat"));
            dict.Add(new KeyValuePair<int, string>(2, "dog"));
            dict.Add(new KeyValuePair<int, string>(3, "tiger"));
            dict.Add(new KeyValuePair<int, string>(4, "bear"));
            dict.Add(new KeyValuePair<int, string>(5, "penguin"));
            dict.Add(new KeyValuePair<int, string>(6, "lion"));
            dict.Add(new KeyValuePair<int, string>(7, "horse"));
            dict.Add(new KeyValuePair<int, string>(8, "eagle"));
            dict.Add(new KeyValuePair<int, string>(9, "fox"));
            dict.Add(new KeyValuePair<int, string>(10, "deer"));
            dict.Add(new KeyValuePair<int, string>(11, "fish"));

            picturelist.Add(Properties.Resources.elephant);
            picturelist.Add(Properties.Resources.cat);
            picturelist.Add(Properties.Resources.dog);
            picturelist.Add(Properties.Resources.tiger);
            picturelist.Add(Properties.Resources.bear);
            picturelist.Add(Properties.Resources.penguin);
            picturelist.Add(Properties.Resources.lion);
            picturelist.Add(Properties.Resources.horse);
            picturelist.Add(Properties.Resources.eagle);
            picturelist.Add(Properties.Resources.fox);
            picturelist.Add(Properties.Resources.deer);
            picturelist.Add(Properties.Resources.fish);
            RandomChange(picturelist);


        }


        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            form_topic form = new form_topic();
            form.ShowDialog();

        }

        private void tb_word_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {



                count++;
                if (dict[idx].Value == tb_word.Text.ToLower())
                {

                    totaltime += 7 - second;
                    score += 20;
                    lb_score.Text = score.ToString();

                    ptb_true.Visible = true;
                    ptb_timesup.Visible = false;
                    ptb_false.Visible = false;
                    tb_word.Text = String.Empty;
                    
                    RandomChange(picturelist);

                }
                else
                {
                    totaltime += 7 - second;
                    ptb_false.Visible = true;
                    ptb_true.Visible = false;
                    ptb_timesup.Visible = false;
                    tb_word.Text = String.Empty;

                    RandomChange(picturelist);
                }
            }


        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void timer_game_Tick(object sender, EventArgs e)
        {
            lb_timer.Text = second--.ToString();
            if (second == -1)
            {
                ptb_timesup.Visible = true;
                ptb_true.Visible=false;
                ptb_false.Visible=false;
                timer_game.Stop();

                totaltime += 7;
                count++;
                RandomChange(picturelist);
            }
        }

        private void ptb_image_Click(object sender, EventArgs e)
        {

        }

        private void ptb_image_BackgroundImageChanged(object sender, EventArgs e)
        {
            
            if (count == 6)
            {
                now = DateTime.Now.ToString("hh:mm:ss");
                Rank_animals.Add(Global.Name, score, now, totaltime);
                this.Close(); 
                timer_game.Stop();
                if (score >= 80)
                {
                    form_end_good form_End_Game = new form_end_good();
                    form_End_Game.topic = 0;
                    form_End_Game.total = totaltime;
                    form_End_Game.time = now;
                    form_End_Game.score = score;
                    form_End_Game.ShowDialog();
                }
                else
                {
                    form_end_bad form_End_Bad = new form_end_bad();
                    form_End_Bad.topic = 0;
                    form_End_Bad.total = totaltime;
                    form_End_Bad.time = now;
                    form_End_Bad.score = score;
                    form_End_Bad.ShowDialog();
                }
            }
            else
            {
                second = 7;
                timer_game.Start();
            }
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

}