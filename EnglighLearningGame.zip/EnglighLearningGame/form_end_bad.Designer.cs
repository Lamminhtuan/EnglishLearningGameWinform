﻿namespace TH01
{
    partial class form_end_bad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_end_bad));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_score = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lb_corrects = new System.Windows.Forms.Label();
            this.ptb_close = new System.Windows.Forms.PictureBox();
            this.btn_again = new System.Windows.Forms.Button();
            this.ptb_home = new System.Windows.Forms.PictureBox();
            this.ptb_mute = new System.Windows.Forms.PictureBox();
            this.ptb_playms = new System.Windows.Forms.PictureBox();
            this.lb_total = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lb_rank = new System.Windows.Forms.Label();
            this.lb_animals = new System.Windows.Forms.Label();
            this.lb_furnitures = new System.Windows.Forms.Label();
            this.lb_fruits = new System.Windows.Forms.Label();
            this.lb_vehicles = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_home)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(302, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 33);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tên người chơi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(401, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 33);
            this.label2.TabIndex = 4;
            this.label2.Text = "Điểm số:";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_name.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_name.Location = new System.Drawing.Point(516, 238);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(0, 33);
            this.lb_name.TabIndex = 4;
            // 
            // lb_score
            // 
            this.lb_score.AutoSize = true;
            this.lb_score.BackColor = System.Drawing.Color.Transparent;
            this.lb_score.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_score.Location = new System.Drawing.Point(516, 271);
            this.lb_score.Name = "lb_score";
            this.lb_score.Size = new System.Drawing.Size(0, 33);
            this.lb_score.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("UTM Swiss Condensed", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(87, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(751, 83);
            this.label3.TabIndex = 5;
            this.label3.Text = "CỐ GẮNG HƠN NỮA BẠN NHÉ!";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(213, 304);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(297, 33);
            this.label4.TabIndex = 4;
            this.label4.Text = "SỐ CÂU TRẢ LỜI ĐÚNG:";
            // 
            // lb_corrects
            // 
            this.lb_corrects.AutoSize = true;
            this.lb_corrects.BackColor = System.Drawing.Color.Transparent;
            this.lb_corrects.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_corrects.Location = new System.Drawing.Point(516, 304);
            this.lb_corrects.Name = "lb_corrects";
            this.lb_corrects.Size = new System.Drawing.Size(0, 33);
            this.lb_corrects.TabIndex = 4;
            // 
            // ptb_close
            // 
            this.ptb_close.BackColor = System.Drawing.Color.Transparent;
            this.ptb_close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_close.BackgroundImage")));
            this.ptb_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_close.Location = new System.Drawing.Point(894, 12);
            this.ptb_close.Name = "ptb_close";
            this.ptb_close.Size = new System.Drawing.Size(50, 50);
            this.ptb_close.TabIndex = 6;
            this.ptb_close.TabStop = false;
            this.ptb_close.Click += new System.EventHandler(this.ptb_close_Click);
            // 
            // btn_again
            // 
            this.btn_again.AutoSize = true;
            this.btn_again.BackColor = System.Drawing.Color.DimGray;
            this.btn_again.Font = new System.Drawing.Font("UTM Tam Le", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.btn_again.Location = new System.Drawing.Point(385, 467);
            this.btn_again.Name = "btn_again";
            this.btn_again.Size = new System.Drawing.Size(131, 61);
            this.btn_again.TabIndex = 7;
            this.btn_again.Text = "Chơi lại";
            this.btn_again.UseVisualStyleBackColor = false;
            this.btn_again.Click += new System.EventHandler(this.btn_again_Click);
            // 
            // ptb_home
            // 
            this.ptb_home.BackColor = System.Drawing.Color.Transparent;
            this.ptb_home.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_home.BackgroundImage")));
            this.ptb_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_home.Location = new System.Drawing.Point(12, 12);
            this.ptb_home.Name = "ptb_home";
            this.ptb_home.Size = new System.Drawing.Size(50, 50);
            this.ptb_home.TabIndex = 6;
            this.ptb_home.TabStop = false;
            this.ptb_home.Click += new System.EventHandler(this.ptb_home_Click);
            // 
            // ptb_mute
            // 
            this.ptb_mute.BackColor = System.Drawing.Color.Transparent;
            this.ptb_mute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_mute.BackgroundImage")));
            this.ptb_mute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_mute.Location = new System.Drawing.Point(894, 478);
            this.ptb_mute.Name = "ptb_mute";
            this.ptb_mute.Size = new System.Drawing.Size(50, 50);
            this.ptb_mute.TabIndex = 14;
            this.ptb_mute.TabStop = false;
            this.ptb_mute.Click += new System.EventHandler(this.ptb_mute_Click);
            // 
            // ptb_playms
            // 
            this.ptb_playms.BackColor = System.Drawing.Color.Transparent;
            this.ptb_playms.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_playms.BackgroundImage")));
            this.ptb_playms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_playms.Location = new System.Drawing.Point(894, 478);
            this.ptb_playms.Name = "ptb_playms";
            this.ptb_playms.Size = new System.Drawing.Size(50, 50);
            this.ptb_playms.TabIndex = 13;
            this.ptb_playms.TabStop = false;
            this.ptb_playms.Click += new System.EventHandler(this.ptb_playms_Click);
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.BackColor = System.Drawing.Color.Transparent;
            this.lb_total.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_total.Location = new System.Drawing.Point(516, 337);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(0, 33);
            this.lb_total.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(179, 337);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(337, 33);
            this.label6.TabIndex = 4;
            this.label6.Text = "THỜI GIAN HOÀN THÀNH:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(369, 370);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 33);
            this.label7.TabIndex = 4;
            this.label7.Text = "XẾP HẠNG:";
            // 
            // lb_rank
            // 
            this.lb_rank.AutoSize = true;
            this.lb_rank.BackColor = System.Drawing.Color.Transparent;
            this.lb_rank.Font = new System.Drawing.Font("UTM Charlotte", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_rank.Location = new System.Drawing.Point(516, 370);
            this.lb_rank.Name = "lb_rank";
            this.lb_rank.Size = new System.Drawing.Size(0, 33);
            this.lb_rank.TabIndex = 4;
            // 
            // lb_animals
            // 
            this.lb_animals.AutoSize = true;
            this.lb_animals.BackColor = System.Drawing.Color.Transparent;
            this.lb_animals.Font = new System.Drawing.Font("UTM Swiss Condensed", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_animals.Location = new System.Drawing.Point(349, 403);
            this.lb_animals.Name = "lb_animals";
            this.lb_animals.Size = new System.Drawing.Size(227, 39);
            this.lb_animals.TabIndex = 5;
            this.lb_animals.Text = "(Chủ đề \"Animals\")";
            this.lb_animals.Visible = false;
            // 
            // lb_furnitures
            // 
            this.lb_furnitures.AutoSize = true;
            this.lb_furnitures.BackColor = System.Drawing.Color.Transparent;
            this.lb_furnitures.Font = new System.Drawing.Font("UTM Swiss Condensed", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_furnitures.Location = new System.Drawing.Point(349, 403);
            this.lb_furnitures.Name = "lb_furnitures";
            this.lb_furnitures.Size = new System.Drawing.Size(251, 39);
            this.lb_furnitures.TabIndex = 15;
            this.lb_furnitures.Text = "(Chủ đề \"Furnitures\")";
            this.lb_furnitures.Visible = false;
            // 
            // lb_fruits
            // 
            this.lb_fruits.AutoSize = true;
            this.lb_fruits.BackColor = System.Drawing.Color.Transparent;
            this.lb_fruits.Font = new System.Drawing.Font("UTM Swiss Condensed", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_fruits.Location = new System.Drawing.Point(385, 403);
            this.lb_fruits.Name = "lb_fruits";
            this.lb_fruits.Size = new System.Drawing.Size(201, 39);
            this.lb_fruits.TabIndex = 16;
            this.lb_fruits.Text = "(Chủ đề \"Fruits\")";
            this.lb_fruits.Visible = false;
            // 
            // lb_vehicles
            // 
            this.lb_vehicles.AutoSize = true;
            this.lb_vehicles.BackColor = System.Drawing.Color.Transparent;
            this.lb_vehicles.Font = new System.Drawing.Font("UTM Swiss Condensed", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_vehicles.Location = new System.Drawing.Point(369, 403);
            this.lb_vehicles.Name = "lb_vehicles";
            this.lb_vehicles.Size = new System.Drawing.Size(231, 39);
            this.lb_vehicles.TabIndex = 17;
            this.lb_vehicles.Text = "(Chủ đề \"Vehicles\")";
            this.lb_vehicles.Visible = false;
            // 
            // form_end_bad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(956, 540);
            this.Controls.Add(this.lb_vehicles);
            this.Controls.Add(this.lb_fruits);
            this.Controls.Add(this.lb_furnitures);
            this.Controls.Add(this.ptb_mute);
            this.Controls.Add(this.ptb_playms);
            this.Controls.Add(this.btn_again);
            this.Controls.Add(this.ptb_home);
            this.Controls.Add(this.ptb_close);
            this.Controls.Add(this.lb_animals);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lb_score);
            this.Controls.Add(this.lb_rank);
            this.Controls.Add(this.lb_total);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_corrects);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form_end_bad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_end_good";
            this.Load += new System.EventHandler(this.form_end_bad_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_home)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label1;
        private Label label2;
        private Label lb_name;
        private Label lb_score;
        private Label label3;
        private Label label4;
        private Label lb_corrects;
        private PictureBox ptb_close;
        private Button btn_again;
        private PictureBox ptb_home;
        private PictureBox ptb_mute;
        private PictureBox ptb_playms;
        private Label lb_total;
        private Label label6;
        private Label label7;
        private Label lb_rank;
        private Label lb_animals;
        private Label lb_furnitures;
        private Label lb_fruits;
        private Label lb_vehicles;
    }
}