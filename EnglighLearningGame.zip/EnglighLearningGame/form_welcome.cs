﻿
using System.Data;
using System.Media;

namespace TH01
{
    
    public partial class form_welcome : Form
    {
       
        
        public form_welcome()
        {
            InitializeComponent();
        }

       
        private void ptb_help_Click(object sender, EventArgs e)
        {
          
            form_help form_Help = new form_help();
            form_Help.ShowDialog();
        }

        private void ptb_dict_Click(object sender, EventArgs e)
        {
            form_dict form_Dict = new form_dict();
            form_Dict.ShowDialog();
        }

       

        private void form_welcome_Load(object sender, EventArgs e)
        {
         
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
            
        
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_rank_Click(object sender, EventArgs e)
        {
            form_rank_topic form_Rank = new form_rank_topic();
            form_Rank.ShowDialog();
        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(tb_player.Text))
            {
                this.Hide();
                Global.Name = tb_player.Text;
                form_topic form_Topic = new form_topic();
                form_Topic.ShowDialog();

            }
            else
                MessageBox.Show("Vui lòng nhập tên người chơi", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}