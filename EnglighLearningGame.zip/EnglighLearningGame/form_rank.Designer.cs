﻿namespace TH01
{
    partial class form_rank
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_rank));
            this.btn_back = new System.Windows.Forms.PictureBox();
            this.ptb_gold = new System.Windows.Forms.PictureBox();
            this.ptb_silver = new System.Windows.Forms.PictureBox();
            this.ptb_bronze = new System.Windows.Forms.PictureBox();
            this.lb_gold_name = new System.Windows.Forms.Label();
            this.lb_silver_name = new System.Windows.Forms.Label();
            this.lb_bronze_name = new System.Windows.Forms.Label();
            this.lb_gold_score = new System.Windows.Forms.Label();
            this.lb_silver_score = new System.Windows.Forms.Label();
            this.lb_bronze_score = new System.Windows.Forms.Label();
            this.lb_gold_time = new System.Windows.Forms.Label();
            this.lb_gold_total = new System.Windows.Forms.Label();
            this.lb_silver_time = new System.Windows.Forms.Label();
            this.lb_silver_total = new System.Windows.Forms.Label();
            this.lb_bronze_time = new System.Windows.Forms.Label();
            this.lb_bronze_total = new System.Windows.Forms.Label();
            this.lb_norow = new System.Windows.Forms.Label();
            this.lb_animals = new System.Windows.Forms.Label();
            this.lb_furnitures = new System.Windows.Forms.Label();
            this.lb_vehicles = new System.Windows.Forms.Label();
            this.lb_fruits = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ptb_mute = new System.Windows.Forms.PictureBox();
            this.ptb_playms = new System.Windows.Forms.PictureBox();
            this.ptb_close = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_gold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_silver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_bronze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.Transparent;
            this.btn_back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_back.BackgroundImage")));
            this.btn_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_back.Location = new System.Drawing.Point(12, 12);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(50, 50);
            this.btn_back.TabIndex = 3;
            this.btn_back.TabStop = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // ptb_gold
            // 
            this.ptb_gold.BackColor = System.Drawing.Color.Transparent;
            this.ptb_gold.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_gold.BackgroundImage")));
            this.ptb_gold.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_gold.Location = new System.Drawing.Point(170, 98);
            this.ptb_gold.Name = "ptb_gold";
            this.ptb_gold.Size = new System.Drawing.Size(60, 60);
            this.ptb_gold.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ptb_gold.TabIndex = 5;
            this.ptb_gold.TabStop = false;
            // 
            // ptb_silver
            // 
            this.ptb_silver.BackColor = System.Drawing.Color.Transparent;
            this.ptb_silver.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_silver.BackgroundImage")));
            this.ptb_silver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_silver.Location = new System.Drawing.Point(170, 180);
            this.ptb_silver.Name = "ptb_silver";
            this.ptb_silver.Size = new System.Drawing.Size(60, 60);
            this.ptb_silver.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ptb_silver.TabIndex = 5;
            this.ptb_silver.TabStop = false;
            // 
            // ptb_bronze
            // 
            this.ptb_bronze.BackColor = System.Drawing.Color.Transparent;
            this.ptb_bronze.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_bronze.BackgroundImage")));
            this.ptb_bronze.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_bronze.Location = new System.Drawing.Point(170, 264);
            this.ptb_bronze.Name = "ptb_bronze";
            this.ptb_bronze.Size = new System.Drawing.Size(60, 60);
            this.ptb_bronze.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ptb_bronze.TabIndex = 5;
            this.ptb_bronze.TabStop = false;
            // 
            // lb_gold_name
            // 
            this.lb_gold_name.AutoSize = true;
            this.lb_gold_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_gold_name.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_gold_name.ForeColor = System.Drawing.Color.Yellow;
            this.lb_gold_name.Location = new System.Drawing.Point(271, 98);
            this.lb_gold_name.Name = "lb_gold_name";
            this.lb_gold_name.Size = new System.Drawing.Size(130, 54);
            this.lb_gold_name.TabIndex = 6;
            this.lb_gold_name.Text = "label2";
            // 
            // lb_silver_name
            // 
            this.lb_silver_name.AutoSize = true;
            this.lb_silver_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_silver_name.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_silver_name.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lb_silver_name.Location = new System.Drawing.Point(271, 184);
            this.lb_silver_name.Name = "lb_silver_name";
            this.lb_silver_name.Size = new System.Drawing.Size(130, 54);
            this.lb_silver_name.TabIndex = 6;
            this.lb_silver_name.Text = "label2";
            // 
            // lb_bronze_name
            // 
            this.lb_bronze_name.AutoSize = true;
            this.lb_bronze_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_bronze_name.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_bronze_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb_bronze_name.Location = new System.Drawing.Point(271, 270);
            this.lb_bronze_name.Name = "lb_bronze_name";
            this.lb_bronze_name.Size = new System.Drawing.Size(130, 54);
            this.lb_bronze_name.TabIndex = 6;
            this.lb_bronze_name.Text = "label2";
            // 
            // lb_gold_score
            // 
            this.lb_gold_score.AutoSize = true;
            this.lb_gold_score.BackColor = System.Drawing.Color.Transparent;
            this.lb_gold_score.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_gold_score.ForeColor = System.Drawing.Color.Yellow;
            this.lb_gold_score.Location = new System.Drawing.Point(417, 98);
            this.lb_gold_score.Name = "lb_gold_score";
            this.lb_gold_score.Size = new System.Drawing.Size(130, 54);
            this.lb_gold_score.TabIndex = 6;
            this.lb_gold_score.Text = "label2";
            // 
            // lb_silver_score
            // 
            this.lb_silver_score.AutoSize = true;
            this.lb_silver_score.BackColor = System.Drawing.Color.Transparent;
            this.lb_silver_score.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_silver_score.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lb_silver_score.Location = new System.Drawing.Point(417, 184);
            this.lb_silver_score.Name = "lb_silver_score";
            this.lb_silver_score.Size = new System.Drawing.Size(130, 54);
            this.lb_silver_score.TabIndex = 6;
            this.lb_silver_score.Text = "label2";
            // 
            // lb_bronze_score
            // 
            this.lb_bronze_score.AutoSize = true;
            this.lb_bronze_score.BackColor = System.Drawing.Color.Transparent;
            this.lb_bronze_score.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_bronze_score.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb_bronze_score.Location = new System.Drawing.Point(417, 270);
            this.lb_bronze_score.Name = "lb_bronze_score";
            this.lb_bronze_score.Size = new System.Drawing.Size(130, 54);
            this.lb_bronze_score.TabIndex = 6;
            this.lb_bronze_score.Text = "label2";
            // 
            // lb_gold_time
            // 
            this.lb_gold_time.AutoSize = true;
            this.lb_gold_time.BackColor = System.Drawing.Color.Transparent;
            this.lb_gold_time.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_gold_time.ForeColor = System.Drawing.Color.Yellow;
            this.lb_gold_time.Location = new System.Drawing.Point(584, 98);
            this.lb_gold_time.Name = "lb_gold_time";
            this.lb_gold_time.Size = new System.Drawing.Size(130, 54);
            this.lb_gold_time.TabIndex = 6;
            this.lb_gold_time.Text = "label2";
            // 
            // lb_gold_total
            // 
            this.lb_gold_total.AutoSize = true;
            this.lb_gold_total.BackColor = System.Drawing.Color.Transparent;
            this.lb_gold_total.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_gold_total.ForeColor = System.Drawing.Color.Yellow;
            this.lb_gold_total.Location = new System.Drawing.Point(781, 98);
            this.lb_gold_total.Name = "lb_gold_total";
            this.lb_gold_total.Size = new System.Drawing.Size(130, 54);
            this.lb_gold_total.TabIndex = 6;
            this.lb_gold_total.Text = "label2";
            // 
            // lb_silver_time
            // 
            this.lb_silver_time.AutoSize = true;
            this.lb_silver_time.BackColor = System.Drawing.Color.Transparent;
            this.lb_silver_time.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_silver_time.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lb_silver_time.Location = new System.Drawing.Point(584, 184);
            this.lb_silver_time.Name = "lb_silver_time";
            this.lb_silver_time.Size = new System.Drawing.Size(130, 54);
            this.lb_silver_time.TabIndex = 6;
            this.lb_silver_time.Text = "label2";
            // 
            // lb_silver_total
            // 
            this.lb_silver_total.AutoSize = true;
            this.lb_silver_total.BackColor = System.Drawing.Color.Transparent;
            this.lb_silver_total.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_silver_total.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lb_silver_total.Location = new System.Drawing.Point(781, 184);
            this.lb_silver_total.Name = "lb_silver_total";
            this.lb_silver_total.Size = new System.Drawing.Size(130, 54);
            this.lb_silver_total.TabIndex = 6;
            this.lb_silver_total.Text = "label2";
            // 
            // lb_bronze_time
            // 
            this.lb_bronze_time.AutoSize = true;
            this.lb_bronze_time.BackColor = System.Drawing.Color.Transparent;
            this.lb_bronze_time.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_bronze_time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb_bronze_time.Location = new System.Drawing.Point(584, 270);
            this.lb_bronze_time.Name = "lb_bronze_time";
            this.lb_bronze_time.Size = new System.Drawing.Size(130, 54);
            this.lb_bronze_time.TabIndex = 6;
            this.lb_bronze_time.Text = "label2";
            // 
            // lb_bronze_total
            // 
            this.lb_bronze_total.AutoSize = true;
            this.lb_bronze_total.BackColor = System.Drawing.Color.Transparent;
            this.lb_bronze_total.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_bronze_total.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb_bronze_total.Location = new System.Drawing.Point(781, 270);
            this.lb_bronze_total.Name = "lb_bronze_total";
            this.lb_bronze_total.Size = new System.Drawing.Size(130, 54);
            this.lb_bronze_total.TabIndex = 6;
            this.lb_bronze_total.Text = "label2";
            // 
            // lb_norow
            // 
            this.lb_norow.AutoSize = true;
            this.lb_norow.BackColor = System.Drawing.Color.Transparent;
            this.lb_norow.Font = new System.Drawing.Font("Tahoma", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lb_norow.ForeColor = System.Drawing.Color.IndianRed;
            this.lb_norow.Location = new System.Drawing.Point(192, 170);
            this.lb_norow.Name = "lb_norow";
            this.lb_norow.Size = new System.Drawing.Size(753, 57);
            this.lb_norow.TabIndex = 8;
            this.lb_norow.Text = "KHÔNG CÓ DỮ LIỆU HIỂN THỊ!";
            this.lb_norow.Visible = false;
            // 
            // lb_animals
            // 
            this.lb_animals.AutoSize = true;
            this.lb_animals.BackColor = System.Drawing.Color.Transparent;
            this.lb_animals.Font = new System.Drawing.Font("UTM American Sans", 28.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lb_animals.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_animals.Location = new System.Drawing.Point(213, 3);
            this.lb_animals.Name = "lb_animals";
            this.lb_animals.Size = new System.Drawing.Size(754, 67);
            this.lb_animals.TabIndex = 9;
            this.lb_animals.Text = "BẢNG XẾP HẠNG CHỦ ĐỀ \"ANIMALS\"";
            this.lb_animals.Visible = false;
            // 
            // lb_furnitures
            // 
            this.lb_furnitures.AutoSize = true;
            this.lb_furnitures.BackColor = System.Drawing.Color.Transparent;
            this.lb_furnitures.Font = new System.Drawing.Font("UTM American Sans", 28.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lb_furnitures.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_furnitures.Location = new System.Drawing.Point(173, 3);
            this.lb_furnitures.Name = "lb_furnitures";
            this.lb_furnitures.Size = new System.Drawing.Size(815, 67);
            this.lb_furnitures.TabIndex = 10;
            this.lb_furnitures.Text = "BẢNG XẾP HẠNG CHỦ ĐỀ \"FURNITURES\"";
            this.lb_furnitures.Visible = false;
            // 
            // lb_vehicles
            // 
            this.lb_vehicles.AutoSize = true;
            this.lb_vehicles.BackColor = System.Drawing.Color.Transparent;
            this.lb_vehicles.Font = new System.Drawing.Font("UTM American Sans", 28.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lb_vehicles.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_vehicles.Location = new System.Drawing.Point(211, 3);
            this.lb_vehicles.Name = "lb_vehicles";
            this.lb_vehicles.Size = new System.Drawing.Size(756, 67);
            this.lb_vehicles.TabIndex = 11;
            this.lb_vehicles.Text = "BẢNG XẾP HẠNG CHỦ ĐỀ \"VEHICLES\"";
            this.lb_vehicles.Visible = false;
            // 
            // lb_fruits
            // 
            this.lb_fruits.AutoSize = true;
            this.lb_fruits.BackColor = System.Drawing.Color.Transparent;
            this.lb_fruits.Font = new System.Drawing.Font("UTM American Sans", 28.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lb_fruits.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_fruits.Location = new System.Drawing.Point(233, 3);
            this.lb_fruits.Name = "lb_fruits";
            this.lb_fruits.Size = new System.Drawing.Size(708, 67);
            this.lb_fruits.TabIndex = 12;
            this.lb_fruits.Text = "BẢNG XẾP HẠNG CHỦ ĐỀ \"FRUITS\"";
            this.lb_fruits.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(247, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 28);
            this.label1.TabIndex = 13;
            this.label1.Text = "Tên người chơi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(433, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 28);
            this.label2.TabIndex = 13;
            this.label2.Text = "Điểm số";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label3.Location = new System.Drawing.Point(552, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 28);
            this.label3.TabIndex = 13;
            this.label3.Text = "Thời điểm hoàn thành";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(781, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(216, 28);
            this.label4.TabIndex = 13;
            this.label4.Text = "Thời gian hoàn thành";
            // 
            // ptb_mute
            // 
            this.ptb_mute.BackColor = System.Drawing.Color.Transparent;
            this.ptb_mute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_mute.BackgroundImage")));
            this.ptb_mute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_mute.Location = new System.Drawing.Point(1095, 623);
            this.ptb_mute.Name = "ptb_mute";
            this.ptb_mute.Size = new System.Drawing.Size(50, 50);
            this.ptb_mute.TabIndex = 15;
            this.ptb_mute.TabStop = false;
            this.ptb_mute.Click += new System.EventHandler(this.ptb_mute_Click);
            // 
            // ptb_playms
            // 
            this.ptb_playms.BackColor = System.Drawing.Color.Transparent;
            this.ptb_playms.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_playms.BackgroundImage")));
            this.ptb_playms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_playms.Location = new System.Drawing.Point(1095, 623);
            this.ptb_playms.Name = "ptb_playms";
            this.ptb_playms.Size = new System.Drawing.Size(50, 50);
            this.ptb_playms.TabIndex = 14;
            this.ptb_playms.TabStop = false;
            this.ptb_playms.Click += new System.EventHandler(this.ptb_playms_Click);
            // 
            // ptb_close
            // 
            this.ptb_close.BackColor = System.Drawing.Color.Transparent;
            this.ptb_close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_close.BackgroundImage")));
            this.ptb_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_close.Location = new System.Drawing.Point(1095, 12);
            this.ptb_close.Name = "ptb_close";
            this.ptb_close.Size = new System.Drawing.Size(50, 50);
            this.ptb_close.TabIndex = 16;
            this.ptb_close.TabStop = false;
            this.ptb_close.Click += new System.EventHandler(this.ptb_close_Click);
            // 
            // form_rank
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1157, 685);
            this.Controls.Add(this.ptb_close);
            this.Controls.Add(this.ptb_mute);
            this.Controls.Add(this.ptb_playms);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_fruits);
            this.Controls.Add(this.lb_vehicles);
            this.Controls.Add(this.lb_furnitures);
            this.Controls.Add(this.lb_animals);
            this.Controls.Add(this.lb_norow);
            this.Controls.Add(this.lb_bronze_total);
            this.Controls.Add(this.lb_bronze_score);
            this.Controls.Add(this.lb_bronze_time);
            this.Controls.Add(this.lb_bronze_name);
            this.Controls.Add(this.lb_silver_total);
            this.Controls.Add(this.lb_silver_score);
            this.Controls.Add(this.lb_silver_time);
            this.Controls.Add(this.lb_silver_name);
            this.Controls.Add(this.lb_gold_total);
            this.Controls.Add(this.lb_gold_score);
            this.Controls.Add(this.lb_gold_time);
            this.Controls.Add(this.lb_gold_name);
            this.Controls.Add(this.ptb_bronze);
            this.Controls.Add(this.ptb_silver);
            this.Controls.Add(this.ptb_gold);
            this.Controls.Add(this.btn_back);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form_rank";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_rank";
            this.Load += new System.EventHandler(this.form_rank_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_gold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_silver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_bronze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private PictureBox btn_back;
        private PictureBox ptb_gold;
        private PictureBox ptb_silver;
        private PictureBox ptb_bronze;
        private Label lb_gold_name;
        private Label lb_silver_name;
        private Label lb_bronze_name;
        private Label lb_gold_score;
        private Label lb_silver_score;
        private Label lb_bronze_score;
        private Label lb_gold_time;
        private Label lb_gold_total;
        private Label lb_silver_time;
        private Label lb_silver_total;
        private Label lb_bronze_time;
        private Label lb_bronze_total;
        private Label lb_norow;
        private Label lb_animals;
        private Label lb_furnitures;
        private Label lb_vehicles;
        private Label lb_fruits;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private PictureBox ptb_mute;
        private PictureBox ptb_playms;
        private PictureBox ptb_close;
    }
}