﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_dict_animals : Form
    {
        public form_dict_animals()
        {
            InitializeComponent();
        }



        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            form_dict form_Dict = new form_dict();
            form_Dict.ShowDialog();
        }

        private void form_dict_animals_Load(object sender, EventArgs e)
        {
            dgv_dict.Rows.Add("Hổ", "Tiger");
            dgv_dict.Rows.Add("Gấu", "Bear");
            dgv_dict.Rows.Add("Sư tử", "Lion");
            dgv_dict.Rows.Add("Voi", "Elephant");
            dgv_dict.Rows.Add("Ngựa", "Horse");
            dgv_dict.Rows.Add("Chó", "Dog");
            dgv_dict.Rows.Add("Cá", "Fish");
            dgv_dict.Rows.Add("Chim cánh cụt", "Penguin");
            dgv_dict.Rows.Add("Đại bàng", "Eagle");
            dgv_dict.Rows.Add("Mèo", "Cat");
            dgv_dict.Rows.Add("Cáo", "Fox");
            dgv_dict.Rows.Add("Nai", "Deer");
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
                        sp.Stream = Properties.Resources.music;

            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;

            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }
    }
}
