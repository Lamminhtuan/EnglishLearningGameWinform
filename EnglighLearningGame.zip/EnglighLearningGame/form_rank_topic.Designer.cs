﻿namespace TH01
{
    partial class form_rank_topic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_rank_topic));
            this.ptb_close = new System.Windows.Forms.PictureBox();
            this.btn_back = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ptb_furnitures = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ptb_animals = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ptb_fruits = new System.Windows.Forms.PictureBox();
            this.ptb_vehicles = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ptb_mute = new System.Windows.Forms.PictureBox();
            this.ptb_playms = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_furnitures)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_animals)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fruits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_vehicles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).BeginInit();
            this.SuspendLayout();
            // 
            // ptb_close
            // 
            this.ptb_close.BackColor = System.Drawing.Color.Transparent;
            this.ptb_close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_close.BackgroundImage")));
            this.ptb_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_close.Location = new System.Drawing.Point(974, 12);
            this.ptb_close.Name = "ptb_close";
            this.ptb_close.Size = new System.Drawing.Size(50, 50);
            this.ptb_close.TabIndex = 1;
            this.ptb_close.TabStop = false;
            this.ptb_close.Click += new System.EventHandler(this.ptb_close_Click);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.Transparent;
            this.btn_back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_back.BackgroundImage")));
            this.btn_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_back.Location = new System.Drawing.Point(12, 12);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(50, 50);
            this.btn_back.TabIndex = 2;
            this.btn_back.TabStop = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("UTM Americana EB", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Sienna;
            this.label1.Location = new System.Drawing.Point(262, -2);
            this.label1.MaximumSize = new System.Drawing.Size(500, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(499, 78);
            this.label1.TabIndex = 3;
            this.label1.Text = "CHỌN CHỦ ĐỀ";
            // 
            // ptb_furnitures
            // 
            this.ptb_furnitures.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_furnitures.BackgroundImage")));
            this.ptb_furnitures.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_furnitures.Location = new System.Drawing.Point(142, 124);
            this.ptb_furnitures.Name = "ptb_furnitures";
            this.ptb_furnitures.Size = new System.Drawing.Size(318, 191);
            this.ptb_furnitures.TabIndex = 4;
            this.ptb_furnitures.TabStop = false;
            this.ptb_furnitures.Click += new System.EventHandler(this.ptb_furnitures_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("UTM Americana EB", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(173, 318);
            this.label3.MaximumSize = new System.Drawing.Size(500, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(258, 56);
            this.label3.TabIndex = 6;
            this.label3.Text = "Furnitures";
            // 
            // ptb_animals
            // 
            this.ptb_animals.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_animals.BackgroundImage")));
            this.ptb_animals.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_animals.Location = new System.Drawing.Point(549, 124);
            this.ptb_animals.Name = "ptb_animals";
            this.ptb_animals.Size = new System.Drawing.Size(318, 191);
            this.ptb_animals.TabIndex = 4;
            this.ptb_animals.TabStop = false;
            this.ptb_animals.Click += new System.EventHandler(this.ptb_animals_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("UTM Americana EB", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(614, 303);
            this.label2.MaximumSize = new System.Drawing.Size(500, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 56);
            this.label2.TabIndex = 6;
            this.label2.Text = "Animals";
            // 
            // ptb_fruits
            // 
            this.ptb_fruits.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_fruits.BackgroundImage")));
            this.ptb_fruits.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_fruits.Location = new System.Drawing.Point(142, 377);
            this.ptb_fruits.Name = "ptb_fruits";
            this.ptb_fruits.Size = new System.Drawing.Size(318, 196);
            this.ptb_fruits.TabIndex = 4;
            this.ptb_fruits.TabStop = false;
            this.ptb_fruits.Click += new System.EventHandler(this.ptb_fruits_Click);
            // 
            // ptb_vehicles
            // 
            this.ptb_vehicles.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_vehicles.BackgroundImage")));
            this.ptb_vehicles.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_vehicles.Location = new System.Drawing.Point(564, 362);
            this.ptb_vehicles.Name = "ptb_vehicles";
            this.ptb_vehicles.Size = new System.Drawing.Size(318, 188);
            this.ptb_vehicles.TabIndex = 4;
            this.ptb_vehicles.TabStop = false;
            this.ptb_vehicles.Click += new System.EventHandler(this.ptb_vehicles_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("UTM Americana EB", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(224, 562);
            this.label4.MaximumSize = new System.Drawing.Size(500, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 56);
            this.label4.TabIndex = 6;
            this.label4.Text = "Fruits";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("UTM Americana EB", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(614, 553);
            this.label5.MaximumSize = new System.Drawing.Size(500, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(220, 56);
            this.label5.TabIndex = 6;
            this.label5.Text = "Vehicles";
            // 
            // ptb_mute
            // 
            this.ptb_mute.BackColor = System.Drawing.Color.Transparent;
            this.ptb_mute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_mute.BackgroundImage")));
            this.ptb_mute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_mute.Location = new System.Drawing.Point(974, 652);
            this.ptb_mute.Name = "ptb_mute";
            this.ptb_mute.Size = new System.Drawing.Size(50, 50);
            this.ptb_mute.TabIndex = 12;
            this.ptb_mute.TabStop = false;
            this.ptb_mute.Click += new System.EventHandler(this.ptb_mute_Click);
            // 
            // ptb_playms
            // 
            this.ptb_playms.BackColor = System.Drawing.Color.Transparent;
            this.ptb_playms.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_playms.BackgroundImage")));
            this.ptb_playms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_playms.Location = new System.Drawing.Point(974, 652);
            this.ptb_playms.Name = "ptb_playms";
            this.ptb_playms.Size = new System.Drawing.Size(50, 50);
            this.ptb_playms.TabIndex = 11;
            this.ptb_playms.TabStop = false;
            this.ptb_playms.Click += new System.EventHandler(this.ptb_playms_Click);
            // 
            // form_rank_topic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1036, 714);
            this.Controls.Add(this.ptb_mute);
            this.Controls.Add(this.ptb_playms);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ptb_vehicles);
            this.Controls.Add(this.ptb_animals);
            this.Controls.Add(this.ptb_fruits);
            this.Controls.Add(this.ptb_furnitures);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.ptb_close);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_rank_topic";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_dict";
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_furnitures)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_animals)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fruits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_vehicles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox ptb_close;
        private PictureBox btn_back;
        private Label label1;
        private PictureBox ptb_furnitures;
        private Label label3;
        private PictureBox ptb_animals;
        private Label label2;
        private PictureBox ptb_fruits;
        private PictureBox ptb_vehicles;
        private Label label4;
        private Label label5;
        private PictureBox ptb_mute;
        private PictureBox ptb_playms;
    }
}