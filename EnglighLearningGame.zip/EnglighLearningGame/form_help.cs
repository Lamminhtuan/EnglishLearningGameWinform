﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_help : Form
    {
        public form_help()
        {
            InitializeComponent();
        }

       

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

     
        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
