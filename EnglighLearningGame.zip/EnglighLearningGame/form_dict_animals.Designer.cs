﻿namespace TH01
{
    partial class form_dict_animals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_dict_animals));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ptb_close = new System.Windows.Forms.PictureBox();
            this.btn_back = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dgv_dict = new System.Windows.Forms.DataGridView();
            this.Vietnamese = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.English = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ptb_mute = new System.Windows.Forms.PictureBox();
            this.ptb_playms = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dict)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).BeginInit();
            this.SuspendLayout();
            // 
            // ptb_close
            // 
            this.ptb_close.BackColor = System.Drawing.Color.Transparent;
            this.ptb_close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_close.BackgroundImage")));
            this.ptb_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_close.Location = new System.Drawing.Point(738, 12);
            this.ptb_close.Name = "ptb_close";
            this.ptb_close.Size = new System.Drawing.Size(50, 50);
            this.ptb_close.TabIndex = 2;
            this.ptb_close.TabStop = false;
            this.ptb_close.Click += new System.EventHandler(this.ptb_close_Click);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.Transparent;
            this.btn_back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_back.BackgroundImage")));
            this.btn_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_back.Location = new System.Drawing.Point(12, 12);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(50, 50);
            this.btn_back.TabIndex = 3;
            this.btn_back.TabStop = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("UTM Amerika Sans", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(266, -2);
            this.label1.MaximumSize = new System.Drawing.Size(500, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 89);
            this.label1.TabIndex = 4;
            this.label1.Text = "ANIMALS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(12, 145);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 183);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // dgv_dict
            // 
            this.dgv_dict.AllowUserToAddRows = false;
            this.dgv_dict.AllowUserToDeleteRows = false;
            this.dgv_dict.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_dict.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_dict.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgv_dict.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_dict.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_dict.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_dict.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Vietnamese,
            this.English});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_dict.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_dict.Location = new System.Drawing.Point(202, 90);
            this.dgv_dict.Name = "dgv_dict";
            this.dgv_dict.RowHeadersWidth = 51;
            this.dgv_dict.RowTemplate.Height = 29;
            this.dgv_dict.Size = new System.Drawing.Size(575, 286);
            this.dgv_dict.TabIndex = 6;
            // 
            // Vietnamese
            // 
            this.Vietnamese.HeaderText = "Tiếng Việt";
            this.Vietnamese.MinimumWidth = 6;
            this.Vietnamese.Name = "Vietnamese";
            // 
            // English
            // 
            this.English.HeaderText = "Tiếng Anh";
            this.English.MinimumWidth = 6;
            this.English.Name = "English";
            // 
            // ptb_mute
            // 
            this.ptb_mute.BackColor = System.Drawing.Color.Transparent;
            this.ptb_mute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_mute.BackgroundImage")));
            this.ptb_mute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_mute.Location = new System.Drawing.Point(12, 344);
            this.ptb_mute.Name = "ptb_mute";
            this.ptb_mute.Size = new System.Drawing.Size(50, 50);
            this.ptb_mute.TabIndex = 10;
            this.ptb_mute.TabStop = false;
            this.ptb_mute.Click += new System.EventHandler(this.ptb_mute_Click);
            // 
            // ptb_playms
            // 
            this.ptb_playms.BackColor = System.Drawing.Color.Transparent;
            this.ptb_playms.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_playms.BackgroundImage")));
            this.ptb_playms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_playms.Location = new System.Drawing.Point(12, 344);
            this.ptb_playms.Name = "ptb_playms";
            this.ptb_playms.Size = new System.Drawing.Size(50, 50);
            this.ptb_playms.TabIndex = 9;
            this.ptb_playms.TabStop = false;
            this.ptb_playms.Click += new System.EventHandler(this.ptb_playms_Click);
            // 
            // form_dict_animals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 406);
            this.Controls.Add(this.ptb_mute);
            this.Controls.Add(this.ptb_playms);
            this.Controls.Add(this.dgv_dict);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.ptb_close);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form_dict_animals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_dict_furnitures";
            this.Load += new System.EventHandler(this.form_dict_animals_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dict)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox ptb_close;
        private PictureBox btn_back;
        private Label label1;
        private PictureBox pictureBox1;
        private DataGridView dgv_dict;
        private DataGridViewTextBoxColumn Vietnamese;
        private DataGridViewTextBoxColumn English;
        private PictureBox ptb_mute;
        private PictureBox ptb_playms;
    }
}