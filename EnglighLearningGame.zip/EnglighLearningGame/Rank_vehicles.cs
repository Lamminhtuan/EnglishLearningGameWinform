﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace TH01
{
    class Rank_vehicles
    {
        public static DataTable dt;
        static Rank_vehicles()
        {
            dt = new DataTable();
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Score", typeof(int));
            dt.Columns.Add("Time", typeof(string));
            dt.Columns.Add("Total", typeof(int));
        }
        public static void Add(string name, int score, string time, int total)
        {
            dt.Rows.Add(name, score, time, total);
        }
    }
  
}
