﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_dict_furnitures : Form
    {
        public form_dict_furnitures()
        {
            InitializeComponent();
        }



        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            form_dict form_Dict = new form_dict();
            form_Dict.ShowDialog();
        }

        private void form_dict_furnitures_Load(object sender, EventArgs e)
        {
            dgv_dict.Rows.Add("Cái bàn", "Table");
            dgv_dict.Rows.Add("Cái ghế", "Chair");
            dgv_dict.Rows.Add("Đài radio", "Radio");
            dgv_dict.Rows.Add("Tủ lạnh", "Refrigerator");
            dgv_dict.Rows.Add("Máy tính xách tay", "Laptop");
            dgv_dict.Rows.Add("Máy vi tính", "Computer");
            dgv_dict.Rows.Add("Tủ sách", "Bookcase");
            dgv_dict.Rows.Add("Điện thoại", "Phone");
            dgv_dict.Rows.Add("Đồng hồ", "Clock");
            dgv_dict.Rows.Add("Cái giường", "Bed");
            dgv_dict.Rows.Add("Truyền hình vô tuyến", "Television");
            dgv_dict.Rows.Add("Đèn để bàn", "Lamp");
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }
    }
}
