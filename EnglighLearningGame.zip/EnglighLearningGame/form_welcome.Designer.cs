﻿namespace TH01
{
    partial class form_welcome
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_welcome));
            this.ptb_close = new System.Windows.Forms.PictureBox();
            this.ptb_dict = new System.Windows.Forms.PictureBox();
            this.ptb_rank = new System.Windows.Forms.PictureBox();
            this.ptb_help = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tb_player = new System.Windows.Forms.TextBox();
            this.ptb_mute = new System.Windows.Forms.PictureBox();
            this.ptb_playms = new System.Windows.Forms.PictureBox();
            this.btn_play = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_dict)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_rank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_help)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).BeginInit();
            this.SuspendLayout();
            // 
            // ptb_close
            // 
            this.ptb_close.BackColor = System.Drawing.Color.Transparent;
            this.ptb_close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_close.BackgroundImage")));
            this.ptb_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_close.Location = new System.Drawing.Point(1043, 12);
            this.ptb_close.Name = "ptb_close";
            this.ptb_close.Size = new System.Drawing.Size(50, 50);
            this.ptb_close.TabIndex = 0;
            this.ptb_close.TabStop = false;
            this.ptb_close.Click += new System.EventHandler(this.ptb_close_Click);
            // 
            // ptb_dict
            // 
            this.ptb_dict.BackColor = System.Drawing.Color.Transparent;
            this.ptb_dict.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_dict.BackgroundImage")));
            this.ptb_dict.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_dict.Location = new System.Drawing.Point(12, 12);
            this.ptb_dict.Name = "ptb_dict";
            this.ptb_dict.Size = new System.Drawing.Size(50, 50);
            this.ptb_dict.TabIndex = 0;
            this.ptb_dict.TabStop = false;
            this.ptb_dict.Click += new System.EventHandler(this.ptb_dict_Click);
            // 
            // ptb_rank
            // 
            this.ptb_rank.BackColor = System.Drawing.Color.Transparent;
            this.ptb_rank.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_rank.BackgroundImage")));
            this.ptb_rank.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_rank.Location = new System.Drawing.Point(12, 68);
            this.ptb_rank.Name = "ptb_rank";
            this.ptb_rank.Size = new System.Drawing.Size(50, 50);
            this.ptb_rank.TabIndex = 0;
            this.ptb_rank.TabStop = false;
            this.ptb_rank.Click += new System.EventHandler(this.ptb_rank_Click);
            // 
            // ptb_help
            // 
            this.ptb_help.BackColor = System.Drawing.Color.Transparent;
            this.ptb_help.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_help.BackgroundImage")));
            this.ptb_help.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_help.Location = new System.Drawing.Point(12, 124);
            this.ptb_help.Name = "ptb_help";
            this.ptb_help.Size = new System.Drawing.Size(50, 50);
            this.ptb_help.TabIndex = 0;
            this.ptb_help.TabStop = false;
            this.ptb_help.Click += new System.EventHandler(this.ptb_help_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(302, 27);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(507, 129);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(234, 162);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(617, 300);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // tb_player
            // 
            this.tb_player.BackColor = System.Drawing.Color.LavenderBlush;
            this.tb_player.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_player.Font = new System.Drawing.Font("UTM Windsor BT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_player.Location = new System.Drawing.Point(413, 486);
            this.tb_player.Name = "tb_player";
            this.tb_player.Size = new System.Drawing.Size(293, 32);
            this.tb_player.TabIndex = 3;
            this.tb_player.Text = "Nhập tên người chơi";
            this.tb_player.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ptb_mute
            // 
            this.ptb_mute.BackColor = System.Drawing.Color.Transparent;
            this.ptb_mute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_mute.BackgroundImage")));
            this.ptb_mute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_mute.Location = new System.Drawing.Point(1043, 596);
            this.ptb_mute.Name = "ptb_mute";
            this.ptb_mute.Size = new System.Drawing.Size(50, 50);
            this.ptb_mute.TabIndex = 0;
            this.ptb_mute.TabStop = false;
            this.ptb_mute.Click += new System.EventHandler(this.ptb_mute_Click);
            // 
            // ptb_playms
            // 
            this.ptb_playms.BackColor = System.Drawing.Color.Transparent;
            this.ptb_playms.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_playms.BackgroundImage")));
            this.ptb_playms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_playms.Location = new System.Drawing.Point(1043, 596);
            this.ptb_playms.Name = "ptb_playms";
            this.ptb_playms.Size = new System.Drawing.Size(50, 50);
            this.ptb_playms.TabIndex = 5;
            this.ptb_playms.TabStop = false;
            this.ptb_playms.Click += new System.EventHandler(this.ptb_playms_Click);
            // 
            // btn_play
            // 
            this.btn_play.BackColor = System.Drawing.Color.DimGray;
            this.btn_play.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_play.BackgroundImage")));
            this.btn_play.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_play.Location = new System.Drawing.Point(478, 524);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(162, 95);
            this.btn_play.TabIndex = 6;
            this.btn_play.UseVisualStyleBackColor = false;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // form_welcome
            // 
            this.AcceptButton = this.btn_play;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1105, 649);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.ptb_playms);
            this.Controls.Add(this.tb_player);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.ptb_help);
            this.Controls.Add(this.ptb_rank);
            this.Controls.Add(this.ptb_dict);
            this.Controls.Add(this.ptb_mute);
            this.Controls.Add(this.ptb_close);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_welcome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.form_welcome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_dict)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_rank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_help)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_mute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_playms)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox ptb_close;
        private PictureBox ptb_dict;
        private PictureBox ptb_rank;
        private PictureBox ptb_help;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private TextBox tb_player;
        private PictureBox ptb_mute;
        private PictureBox ptb_playms;
        private Button btn_play;
    }
}