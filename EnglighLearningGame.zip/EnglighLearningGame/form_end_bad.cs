﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace TH01
{
    public partial class form_end_bad : Form
    {
        public string time { get; set; }
        public int total { get; set; }
        public int score { get; set; }
        public int topic { get; set; }
        int index;
        public form_end_bad()
        {
            InitializeComponent();
        }

       

        private void form_end_bad_Load(object sender, EventArgs e)
        {
            if (topic == 0)
            {
                Rank_animals.dt.DefaultView.Sort = "Score DESC, Total ASC";
                Rank_animals.dt = Rank_animals.dt.DefaultView.ToTable();
                string query = "Time = '" + time + "'";
                DataRow[] rows = Rank_animals.dt.Select(query);
             
                index = Rank_animals.dt.Rows.IndexOf(rows[0]) + 1;
                lb_animals.Visible = true;
            }
            else if (topic == 1)
            {
                Rank_fruits.dt.DefaultView.Sort = "Score DESC, Total ASC";
                Rank_fruits.dt = Rank_fruits.dt.DefaultView.ToTable();
                string query = "Time = '" + time + "'";
                DataRow[] rows = Rank_fruits.dt.Select(query);

                index = Rank_fruits.dt.Rows.IndexOf(rows[0]) + 1;
                lb_fruits.Visible = true;
            }
            else if (topic == 2)
            {
                Rank_furnitures.dt.DefaultView.Sort = "Score DESC, Total ASC";
                Rank_furnitures.dt = Rank_furnitures.dt.DefaultView.ToTable();
                string query = "Time = '" + time + "'";
                DataRow[] rows = Rank_furnitures.dt.Select(query);

                index = Rank_furnitures.dt.Rows.IndexOf(rows[0]) + 1;
                lb_furnitures.Visible = true;
            }
            else
            {
                Rank_vehicles.dt.DefaultView.Sort = "Score DESC, Total ASC";
                Rank_vehicles.dt = Rank_vehicles.dt.DefaultView.ToTable();
                string query = "Time = '" + time + "'";
                DataRow[] rows = Rank_vehicles.dt.Select(query);

                index = Rank_vehicles.dt.Rows.IndexOf(rows[0]) + 1;
                lb_vehicles.Visible = true;
            }
            lb_rank.Text = index.ToString();    
            lb_total.Text = total.ToString();   
            lb_name.Text = Global.Name;
            lb_score.Text = score.ToString();
       
            lb_corrects.Text = (score / 20).ToString();
        }

       

        private void btn_again_Click(object sender, EventArgs e)
        {
            this.Close();
            form_topic form_Topic = new form_topic();
            form_Topic.ShowDialog();
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ptb_home_Click(object sender, EventArgs e)
        {
            this.Close();
            form_welcome form_Welcome = new form_welcome(); 
            form_Welcome.ShowDialog();
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }
    }
}   
