﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Timers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TH01
{
    public partial class form_game_fruits: Form
    {
        int second = 0;
        int score = 0;
        int count = 1;
        string now;
        int totaltime = 0;
        int idx;
        List<KeyValuePair<int, string>> dict = new List<KeyValuePair<int, string>>();
        List<Bitmap> picturelist = new List<Bitmap>();
        List<int> used = new List<int>();
        public form_game_fruits()
        {
            InitializeComponent();
        }
        public void RandomChange(List<Bitmap> list)
        {
            int temp;
            Random random = new Random();
            do
            {
                temp = random.Next(0, list.Count);
            } while (used.Contains(temp));
            used.Add(temp);
            idx = temp;
            ptb_image.BackgroundImage = list[idx];
        }

        private void form_game_fruits_Load(object sender, EventArgs e)
        {
            lb_name.Text = Global.Name;

            second = 7;
            timer_game.Start();


            lb_score.Text = score.ToString();
            dict.Add(new KeyValuePair<int, string>(0, "coconut"));
            dict.Add(new KeyValuePair<int, string>(1, "pineapple"));
            dict.Add(new KeyValuePair<int, string>(2, "strawberry"));
            dict.Add(new KeyValuePair<int, string>(3, "avocado"));
            dict.Add(new KeyValuePair<int, string>(4, "grape"));
            dict.Add(new KeyValuePair<int, string>(5, "orange"));
            dict.Add(new KeyValuePair<int, string>(6, "lemon"));
            dict.Add(new KeyValuePair<int, string>(7, "kiwi"));
            dict.Add(new KeyValuePair<int, string>(8, "apple"));
            dict.Add(new KeyValuePair<int, string>(9, "watermelon"));
            dict.Add(new KeyValuePair<int, string>(10, "pear"));
            dict.Add(new KeyValuePair<int, string>(11, "banana"));

            picturelist.Add(Properties.Resources.coconut);
            picturelist.Add(Properties.Resources.pineapple);
            picturelist.Add(Properties.Resources.strawberry);
            picturelist.Add(Properties.Resources.avocado);
            picturelist.Add(Properties.Resources.grape);
            picturelist.Add(Properties.Resources.orange);
            picturelist.Add(Properties.Resources.lemon);
            picturelist.Add(Properties.Resources.kiwi);
            picturelist.Add(Properties.Resources.apple);
            picturelist.Add(Properties.Resources.watermelon);
            picturelist.Add(Properties.Resources.pear);
            picturelist.Add(Properties.Resources.banana);
            RandomChange(picturelist);


        }


        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            form_topic form = new form_topic();
            form.ShowDialog();
        }

        private void tb_word_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {



                count++;
                if (dict[idx].Value == tb_word.Text.ToLower())
                {


                    score += 20;
                    lb_score.Text = score.ToString();
                    totaltime += 7 - second;
                    ptb_true.Visible = true;
                    ptb_timesup.Visible = false;
                    ptb_false.Visible = false;
                    tb_word.Text = String.Empty;
                    
                    RandomChange(picturelist);

                }
                else
                {
                    ptb_false.Visible = true;
                    ptb_true.Visible = false;
                    ptb_timesup.Visible = false;
                    tb_word.Text = String.Empty;
                    totaltime += 7 - second;
                    RandomChange(picturelist);
                }
            }


        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void timer_game_Tick(object sender, EventArgs e)
        {
            lb_timer.Text = second--.ToString();
            if (second == -1)
            {
                ptb_timesup.Visible = true;
                ptb_true.Visible=false;
                ptb_false.Visible=false;
                timer_game.Stop();

                totaltime += 7;
                count++;
                RandomChange(picturelist);
            }
        }

        private void ptb_image_Click(object sender, EventArgs e)
        {

        }

        private void ptb_image_BackgroundImageChanged(object sender, EventArgs e)
        {

            if (count == 6)
            {
                now = DateTime.Now.ToString("hh:mm:ss");
                Rank_fruits.Add(Global.Name, score, now, totaltime);
                this.Close();
                timer_game.Stop();
                if (score >= 80)
                {
                    form_end_good form_End_Game = new form_end_good();
                    form_End_Game.score = score;
                    form_End_Game.topic = 1;
                    form_End_Game.total = totaltime;
                    form_End_Game.time = now;
                    form_End_Game.ShowDialog();
                }
                else
                {
                    form_end_bad form_End_Bad = new form_end_bad();
                    form_End_Bad.topic = 1;
                    form_End_Bad.total = totaltime;
                    form_End_Bad.time = now;
                    form_End_Bad.score = score;
                    form_End_Bad.ShowDialog();
                }
            }
            else
            {
                second = 7;
                timer_game.Start();
            }
        }

        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

}