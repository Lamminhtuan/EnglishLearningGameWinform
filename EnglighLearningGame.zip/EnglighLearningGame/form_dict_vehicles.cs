﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_dict_vehicles : Form
    {
        public form_dict_vehicles()
        {
            InitializeComponent();
        }



        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            form_dict form_Dict = new form_dict();
            form_Dict.ShowDialog();
        }

        private void form_dict_vehicles_Load(object sender, EventArgs e)
        {
            dgv_dict.Rows.Add("Xe tải", "Truck");
            dgv_dict.Rows.Add("Khinh khí cầu", "Balloon");
            dgv_dict.Rows.Add("Tàu lửa", "Train");
            dgv_dict.Rows.Add("Máy kéo", "Tractor");
            dgv_dict.Rows.Add("Xe đạp", "Bicycle");
            dgv_dict.Rows.Add("Thuyền buồm", "Sailboat");
            dgv_dict.Rows.Add("Xe buýt", "Bus");
            dgv_dict.Rows.Add("Xe máy", "Motorcycle");
            dgv_dict.Rows.Add("Xe cứu thương", "Ambulance");
            dgv_dict.Rows.Add("Máy bay", "Plane");
            dgv_dict.Rows.Add("Trực thăng", "Helicopter");
            dgv_dict.Rows.Add("Xe hơi", "Car");
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }
    }
}
