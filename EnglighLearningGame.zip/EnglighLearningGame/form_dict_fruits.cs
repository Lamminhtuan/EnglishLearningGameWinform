﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01
{
    public partial class form_dict_fruits : Form
    {
        public form_dict_fruits()
        {
            InitializeComponent();
        }



        private void ptb_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            form_dict form_Dict = new form_dict();
            form_Dict.ShowDialog();
        }

        private void form_dict_fruits_Load(object sender, EventArgs e)
        {
            dgv_dict.Rows.Add("Dứa", "Pineapple");
            dgv_dict.Rows.Add("Dừa", "Coconut");
            dgv_dict.Rows.Add("Dâu tây", "Strawberry");
            dgv_dict.Rows.Add("Quả lê", "Pear");
            dgv_dict.Rows.Add("Kiwi", "Kiwi");
            dgv_dict.Rows.Add("Chanh", "Lemon");
            dgv_dict.Rows.Add("Quả cam", "Orange");
            dgv_dict.Rows.Add("Dưa hấu", "Watermelon");
            dgv_dict.Rows.Add("Quả bơ", "Avocado");
            dgv_dict.Rows.Add("Chuối", "Banana");
            dgv_dict.Rows.Add("Táo", "Apple");
            dgv_dict.Rows.Add("Nho", "Grape");
        }

        private void ptb_mute_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.Stop();
            ptb_playms.Visible = true;
            ptb_mute.Visible = false;
        }

        private void ptb_playms_Click(object sender, EventArgs e)
        {
            SoundPlayer sp = new SoundPlayer();
            sp.Stream = Properties.Resources.music;
            sp.PlayLooping();
            ptb_mute.Visible = true;
            ptb_playms.Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
